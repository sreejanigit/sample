# simple-factory-python
A simple example of how to implement the Factory method design pattern in Python
