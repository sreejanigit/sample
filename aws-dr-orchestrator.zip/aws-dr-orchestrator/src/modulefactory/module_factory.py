from service_module import ServiceModule
from modules import EventBridge, AuroraMySQL


# Creator
class ModuleFactory:
    @staticmethod
    def create(service_module: ServiceModule):
        match service_module:
            case ServiceModule.EventBridge:
                return EventBridge()
            case ServiceModule.AuroraMySQL:
                return AuroraMySQL()            
            case _:
                raise ValueError(
                    f"{service_module} is not currently registered as a module."
                )
