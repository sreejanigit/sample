from enum import Enum


class ServiceModule(Enum):
    EventBridge = 1
    AuroraMySQL = 2

