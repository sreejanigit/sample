from .module import Module
from .utils.boto3_session import Boto3Session
import os
import inspect
import sys
import botocore

# ConcreteProductA
class AuroraMySQL(Module):

    def get_db_instance_status(self, db_cluster_identifiers, db_instance_identifiers):
        try:
            for instance in db_instance_identifiers:
                status = self.service_client.describe_db_instances(DBInstanceIdentifier=instance)['DBInstances'][0]['DBInstanceStatus']
                self.logger.debug(status)
                if status in ['creating', 'configuring-enhanced-monitoring']:
                    return "CREATING"
                elif status != 'available':
                    raise Exception(f"Aurora DB instance {instance} is not in either creating, configuring-enhanced-monitoring or available state.")
            return 'AVAILABLE'                    
        except botocore.exceptions.ClientError as e:
            self.logger.log_unhandled_exception(e)
            raise

    def is_headless(self, db_cluster_identifier):
        try:
            db_cluster_members = self.service_client.describe_db_clusters(DBClusterIdentifier=db_cluster_identifier)['DBClusters'][0]['DBClusterMembers']
            self.logger.debug(db_cluster_members)
            if len(db_cluster_members) > 0:
                return {"value": len(db_cluster_members)}
            else:
                return {"value": "HEADLESS"}

        except botocore.exceptions.ClientError as e:
            self.logger.log_unhandled_exception(e)
            raise

    # def is_failover_complete(self, db_cluster_identifier):
    #     try:


    #     except ClientError as e:
    #         self.logger.log_unhandled_exception(e)
    #         raise

    def create_headnodes(self, global_cluster_identifier, db_cluster_identifier, db_instance_identifers ):
        try:
            response = self.service_client.describe_global_clusters(
                GlobalClusterIdentifier = global_cluster_identifier
            )
            self.logger.debug(response)

            if self.is_headless(db_cluster_identifier)["value"] == "HEADLESS":
                engine = response["GlobalClusters"][0]["Engine"]
                engine_version = response["GlobalClusters"][0]["EngineVersion"]
                
                for instance in db_instance_identifers:
                    response = self.service_client.create_db_instance(
                        DBClusterIdentifier = db_cluster_identifier,
                        DBInstanceIdentifier = instance,
                        DBInstanceClass = f'db.serverless',
                        Engine = engine,
                        EngineVersion = engine_version
                    )
                    self.logger.debug(response)
            else:
                raise Exception("Head nodes already exists")
        except botocore.exceptions.ClientError as e:
            self.logger.log_unhandled_exception(e)
            raise

    # def delete_headnodes(self, db_cluster_identifier):
    #     try:
    #         response = client.describe_db_instances(
    #             Filters = [
    #             {
    #                 'Name': 'db-cluster-id',
    #                 'Values': [
    #                     db_cluster_identifier
    #                 ]
    #             }
    #             ]
    #         )
    #         db_instances = response['DBInstances']
    #         for db_instance in db_instances:
    #             db_identifier = db_instance['DBInstanceIdentifier']
    #             logger.info(f'Deleting instance {db_identifier}')
    #             client.delete_db_instance( 
    #                 DBInstanceIdentifier=db_identifier, 
    #                 SkipFinalSnapshot=True,
    #                 DeleteAutomatedBackups=True
    #             )

    #     except botocore.exceptions.ClientError as e:
    #         self.logger.log_unhandled_exception(e)
    #         raise

    @Module.init
    def instantiate(self, event, boto3_service_name='rds'):
        self.create_headnodes(
            self, 
            db_cluster_identifier=event['StatePayload']['parameters']['DBClusterIdentifier'],
            db_instance_identifiers=event['StatePayload']['parameters']['DBInstanceIdentifiers'],
            global_cluster_identifier=event['StatePayload']['parameters']['GlobalClusterIdentifier']
        )

    def instantiate_status_check(self, event, boto3_service_name='rds'):
        db_cluster_identifier=event['StatePayload']['parameters']['DBClusterIdentifier'],
        db_instance_identifiers=event['StatePayload']['parameters']['DBInstanceIdentifiers'],
        status = self.get_db_instance_status(self, db_cluster_identifier, db_instance_identifiers)
        if status == "AVAILABLE":
            return True
        else:
            return False

    # @Module.init
    # def activate(self, event, boto3_service_name='rds'):
    #         self.enable_event(
    #             event_name=event['StatePayload']['parameters']['EventRuleName'], 
    #             event_bus=event['StatePayload']['parameters']['BusName']
    #         )

    # @Module.init
    # def activate_status_check(self, event, boto3_service_name='events'):
    #     status = self.describe_event(event_name=event['StatePayload']['parameters']['EventRuleName'], event_bus=event['StatePayload']['parameters']['BusName'])
    #     if status == "ENABLED":
    #         return True
    #     elif status== "DISABLED":
    #         return False
    #     else:
    #         return Exception("Rule did not transition to ENABLED state. Please verify.")

    # def replicate(self):
    #     raise Exception("Replicate is not applicable to EventBridge capability")

    # def replicate_status_check(self):
    #     raise Exception("Replicate is not applicable to EventBridge capability")

    # @Module.init
    # def cleanup(self, event, boto3_service_name='events'):
    #     self.disable_event(
    #         event_name=event['StatePayload']['parameters']['EventRuleName'], 
    #         event_bus=event['StatePayload']['parameters']['BusName']
    #     )

    # @Module.init
    # def cleanup_status_check(self, event, boto3_service_name='events'):
    #     status = self.describe_event(event_name=event['StatePayload']['parameters']['EventRuleName'], event_bus=event['StatePayload']['parameters']['BusName'])
    #     if status == "DISABLED":
    #         return True
    #     elif status== "ENABLED":
    #         return False
    #     else:
    #         return Exception("Rule did not transition to DISABLED state. Please verify.")

