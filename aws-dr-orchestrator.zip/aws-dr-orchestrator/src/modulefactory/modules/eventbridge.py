from .module import Module
from .utils.boto3_session import Boto3Session
import os
import inspect
import sys
from .utils.logger import Logger
import botocore


class EventBridge(Module):

    boto3_service_name='events'
    
    ### Custom functions ###
    def enable_event(self, event_name, event_bus):
        try:
            response = self.service_client.enable_rule(
                Name=event_name,
                EventBusName=event_bus
            )
            self.logger.info(response)
            return response
        except botocore.exceptions.ClientError as e:
            self.logger.log_unhandled_exception(e)
            raise

    def disable_event(self, event_name, event_bus):
        try:
            response = self.service_client.disable_rule(
                Name=event_name,
                EventBusName=event_bus
            )
            return response
        except botocore.exceptions.ClientError as e:
            self.logger.log_unhandled_exception(e)
            raise

    def describe_event(self, event_name, event_bus):
        try:
            response = self.service_client.describe_rule(
                Name=event_name,
                EventBusName=event_bus
            )
            return response["State"]
        except botocore.exceptions.ClientError as e:
            self.logger.log_unhandled_exception(e)
            raise            

    ### Lifecycle functions ###
    
    ### instantiate ###
    def instantiate(self, event):
        raise Exception("Instantiate is not applicable to EventBridge capability")

    def instantiate_status_check(self, event):
        raise Exception("Instantiate is not applicable to EventBridge capability")

    ### activate ###
    @Module.init
    def activate(self, event):
      self.enable_event(self,
            event_name=event['StatePayload']['parameters']['EventRuleName'], 
            event_bus=event['StatePayload']['parameters']['BusName']
        )

    @Module.init
    def activate_status_check(self, event):  
        status = self.describe_event(self, 
                                    event_name=event['StatePayload']['parameters']['EventRuleName'], 
                                    event_bus=event['StatePayload']['parameters']['BusName']
                                    )
        self.logger.info(f"status: {status}")
        if status == "ENABLED":
            return True
        elif status == "DISABLED":
            return False
        else:
            return Exception("Rule did not transition to ENABLED state. Please verify.")

    ### replicate ###
    def replicate(self, event):
        raise Exception("Replicate is not applicable to EventBridge capability")

    def replicate_status_check(self, event):
        raise Exception("Replicate is not applicable to EventBridge capability")

    ### cleanup ###
    @Module.init
    def cleanup(self, event):  
        self.disable_event(self, 
            event_name=event['StatePayload']['parameters']['EventRuleName'], 
            event_bus=event['StatePayload']['parameters']['BusName']
        )

    @Module.init
    def cleanup_status_check(self, event):                 
        status = self.describe_event(self,
                                    event_name=event['StatePayload']['parameters']['EventRuleName'], 
                                    event_bus=event['StatePayload']['parameters']['BusName']
                                    )
        if status == "DISABLED":
            return True
        elif status == "ENABLED":
            return False
        else:
            return Exception("Rule did not transition to DISABLED state. Please verify.")

