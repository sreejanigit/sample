from dynamic_module_factory import DynamicModuleFactory
from module_factory import ModuleFactory
from service_module import ServiceModule


# Client
def lambda_handler(event, context):
    factory = DynamicModuleFactory()
    module = factory.create(event['StatePayload']['resourceType'])
    if 'status' in event:
        return module.call_lifecycle(name=f"{event['LifeCyclePhase']}_status_check", event=event)
    else:
        return module.call_lifecycle(name=event['LifeCyclePhase'], event=event)


if __name__ == "__main__":
    lambda_handler(event={
  "StatePayload": {
    "resourceType": "EventBridge",
    "resourceName": "BlmgBatchTrigger",
    "parameters": {
      "AccountId": "921235537445",
      "EventRuleName": "MioTestStack-ruleF2C1DCDC-8lTDOwK0gria",
      "BusName": "default",
      "test":"!Import app3DbCluster"
    }
  },
  "TaskToken": "AQCYAAAAKgAAAAMAAAAAAAAAAQR4VFN6eSdyGzxVIa+OPnZy+BKOXAj+jgwbULECwYPEZV2ug+rTCmbgYfKDtp9nL0YlgdzKpGgUFgp5php46HyxcUmmvMuYEHGdzopA81nF8QQEPzSZjw8vf5gfzYPo71g=YvekRk4GfpEoui5gGGwh3nsl/0orLGwSFlT/TKB0IBx3fKeK59FAt5LtWh0VOLb5uKlM1+H2VPgyb4gestuqwVonVo1Qwz384Nlus77409ca2Ru4a2AWCCDR5pl9bmJIeqBe8JRZ0Kw5WldeLU563e84YBlQF0TaL79lydMkC2zuPxoJWqDZEuP3mfOIrTNnu8rcUr8D81CGmh7SXXrCPpEksxPacCn16b5Uu530+246/MqUP5YwhdzFphigZOgwwfFwcyU7TRX+rRYsMd3YzTpyg5OlLJYRBdze7esUgzlZPv7c0VOCAurZshMlzZrfI7vMo1u1cYiFzCVO5jWBzwaUwdfDVDOSX1RY6J1TW0KXBAQCxcrTjzr5E1iHlmXmaidpL7fueQR5+3w2BVE1vvOEHQzfF8EYlrRmTt0jlnHMeGm5DWvFkYU6CHen8AxJTmdA5S5uPnoBxa4V42T6dGvxp5Q6LEehpzAa7FGv3QCmnguRI5QAIDYGCUly2AphPeIwGDcnTWNA/OBxOqQS",
  "LifeCyclePhase": "activate",
  "AppName": "MDR",
  "status": False
}, context={})
